package user;
 
/**
 * <PRE>
 * 1. FileName : ${user}
 * 2. Package  :  ${user}
 * 3. Comment  : DB연결이 이루어지는 java파일이며 연결 실패 시에는 로딩실페 시스템 메시지와 함께 사용자에게 오류정보 출력을 위해  catch (SQLException e1)를 사용하여 오류정보를 가져온다.
 * 4. 작성자   : ${174214 양홍엽}
 * </PRE>
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
 //DB 커넥션 연결 코드

/**
 * <PRE>
 * 1. ClassName : ${asdf}
 * 2. FileName  : ${user}
 * 3. Package  : ${user}
 * 4. Comment  :DB연결이 이루어지는 java파일이며 연결 실패 시에는 로딩실페 시스템 메시지와 함께 사용자에게 오류정보 출력을 위해  catch (SQLException e1)를 사용하여 오류정보를 가져온다.
 * 5. 작성자   : ${174214 양홍엽}
 * </PRE>
 */

public class asdf {
    private Connection conn; //DB 커넥션 연결 객체
    private static final String USERNAME = "root";//DBMS접속 시 아이디
    private static final String PASSWORD = "1234";//DBMS접속 시 비밀번호
    private static final String URL = "jdbc:mysql://localhost:3306/coindb";//DBMS접속할 db명
    
    public asdf() {
        try {
            System.out.println("생성자");
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("드라이버 로딩 성공");
        } catch (Exception e) {
            System.out.println("드라이버 로딩 실패 ");
            try {
                conn.close();
            } catch (SQLException e1) {    }
        }
        
        
    }
}
