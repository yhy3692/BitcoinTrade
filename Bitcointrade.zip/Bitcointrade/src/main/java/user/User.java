package user;


/**
 * <PRE>
 * 1. FileName : ${user}
 * 2. Package  :  ${user}
 * 3. Comment  : /generate getter, setter method를 사용하여 각 객체의 값을 받거나 전해준다.
 * 4. 작성자   : ${174214 양홍엽}
 * </PRE>
 */
/**
 * <PRE>
 * 1. ClassName : ${User}
 * 2. FileName  : ${user}
 * 3. Package  : ${user}
 * 4. Comment  :/generate getter, setter method를 사용하여 각 객체의 값을 받거나 전해준다.
 * 5. 작성자   : ${174214 양홍엽}
 * </PRE>
 */
public class User {
	private String userID;
	private String userPassword;
	private String userName;

	
	
	//generate getter / setter method를 사용하여 각 객체의 값을 받거나 전해준다.
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}	
	
	
	
}

