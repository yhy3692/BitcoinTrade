package user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


/**
 * <PRE>
 * 1. FileName  : ${user}
 * 2. Package  : ${user}
 * 3. Comment  : 데이터베이스 연동 시 필요한 정보와 로그인 확인 리퀘스트 값의 판별시 필요한 코드입니다. 
 * 4. 작성자   : ${174214 양홍엽}
 * </PRE>
 */

/**
 * <PRE>
 * 1. ClassName : ${UserDAO}
 * 2. FileName  : ${user}
 * 3. Package  : ${user}
 * 4. Comment  :데이터베이스 연동 시 필요한 정보 저장과 public int login()를 통해 로그인 확인 리퀘스트 값의 판별시 필요한 코드입니다.
 * 5. 작성자   : ${174214 양홍엽}
 * </PRE>
 */
public class UserDAO {

 private Connection conn; //데이터베이스 접근 객체
 private PreparedStatement pstmt; //데이터베이스 처리문을 효과적으로 처리하기 위한 객체입니다. 특정상수값 반복처리
 private ResultSet rs; //정보를 담기위한 객체

 public UserDAO() {
  try { //try catch exception을 활용하여 오류가 뜨는 부분을 캐치하여 오류메시지를 전송합니다.
   String dbURL = "jdbc:mysql://localhost:3308/boarddb"; //mysql의 내가 열어둔 포트번호와 데이터베이스 이름 3306포트를 사용하여 접속
   String dbID = "root"; //데이터베이스 id
   String dbPassword = "1234"; // 데이터베이스 암호
   Class.forName("com.mysql.cj.jdbc.Driver");
   conn = DriverManager.getConnection(dbURL, dbID, dbPassword);

  } catch (Exception e) {
   e.printStackTrace();
  }
 }
//로크인 확인 리퀘스트 값 알고리즘 
 public int login(String userID, String userPassword) {
  String SQL = "SELECT userPassword FROM USER WHERE userID=?";
  try {
   pstmt = conn.prepareStatement(SQL);
   pstmt.setString(1, userID);
   rs = pstmt.executeQuery();
   if(rs.next()) {
    if(rs.getString(1).equals(userPassword))
     return 1;  // 로그인완료
    else
     return 0;  // 비번 불일치
   }
   return -1;  // 아이디 없음
   
  } catch(Exception e) {
   e.printStackTrace();
  }
  return -2; // 데이터 베이스 오류 - 보통 데이터베이스에 연결이 되지않았을때 생기는 오류

 }
}